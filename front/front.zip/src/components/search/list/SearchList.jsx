import React from "react";

//검색 결과
const SearchList = () => {
  return (
    <>
      <h1>검색 결과 위스키 리스트</h1>
    </>
  );
};

export default SearchList;
