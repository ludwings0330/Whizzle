import React from "react";

//메인화면에 띄워줄 추천부분(비로그인 사용자)
const MainRecommend = () => {
  return <></>;
};

export default MainRecommend;
