import React from "react";
import styled from "styled-components";

const MainReviewItem = () => {
  return <></>;
};

export default MainReviewItem;
