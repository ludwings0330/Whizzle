import React from "react";

//에러 발생 시 보여줄 컴포넌트
const Error = () => {
  return (
    <>
      <h1>에러발생</h1>
    </>
  );
};

export default Error;
