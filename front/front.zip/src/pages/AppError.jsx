import React from "react";

const AppError = () => {
  return (
    <>
      <h1>에러페이지</h1>
    </>
  );
};

export default AppError;
