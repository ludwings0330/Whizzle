# 특정 위스키와 유사한 위스키 조회 - [spring → fastAP

Method: GET
URL: /rec/similar-whisky/{whiskyId}
권한: ANONYMOUS
담당자: IHRUG
현황: Done

# Request

---

## Headers

```json

```

## Params

```json
// path variable
1~3535
```

## Body

```json
x
```

# Response

---

### 성공

📌 Status : Created, 200 ( 성공 )

- 유사한 위스키 상위 5개

```json
[652,12,841,231,86]
```

---

### 실패

💥 Status : Not found, 404( Page Not Found - 일치하는 method, uri 없음 )

```json
x
```

💥 Status : Unprocessable Content, 422 ( uri로 넘어온 데이터 오류 )

```json
x
```

💥 Status : Internal Server Error, 500 ( fastAPI 내부 오류 )

```json
x
```

# 참고

---

1.