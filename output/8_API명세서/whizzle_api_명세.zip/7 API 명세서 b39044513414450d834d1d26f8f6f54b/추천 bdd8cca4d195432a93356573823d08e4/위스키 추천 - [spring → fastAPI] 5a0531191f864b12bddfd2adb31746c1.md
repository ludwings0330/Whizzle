# 위스키 추천 - [spring → fastAPI]

Method: POST
URL: /rec/personal-whisky
권한: ANONYMOUS
담당자: IHRUG
현황: Done

# Request

---

## Headers

```json
x
```

## Params

```json
x
```

## Body

```json
{
	// 학습에 포함되지 않은 신규 사용자 : 0 || 학습에 포함된 사용자 : n
	(int) memberId: [0 || n],
	(int) priceTier: [1~5],
	(float) smoky: [0~1]
	(float) peaty: [0~1],
	(float) spicy: [0~1],
	(float) herbal: [0~1],
	(float) oily: [0~1],
	(float) body: [0~1],
	(float) rich: [0~1],
	(float) sweet: [0~1],
	(float) salty: [0~1],
	(float) vanilla: [0~1],
	(float) tart: [0~1],
	(float) fruity: [0~1],
	(float) floral: [0~1]
}
```

# Response

---

### 성공

📌 Status : OK, 200 ( 성공 )

```json
// 추천 순위로 정렬된 whisky index List
[
    2558,
    1180,
    2367,
    2344,
    2486,
		...
]
```

---

### 실패

💥 Status : Unprocessable Entity, 422 ( InValidation Error )

- spring에서 전달받은 파라미터 에러

```json
x
```

💥 Status : Internal Server Error, 500( fastAPI 서버 오류 )

```json
x
```

# 참고

---

1.