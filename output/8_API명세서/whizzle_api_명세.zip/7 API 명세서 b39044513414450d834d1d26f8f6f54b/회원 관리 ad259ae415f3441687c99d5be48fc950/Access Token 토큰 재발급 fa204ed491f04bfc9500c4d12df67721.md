# Access Token 토큰 재발급

Method: GET
URI: /api/auth/refresh
권한: MEMBER
담당자: Basic
현황: Done

# Request

---

## Headers

```json
Authorization : Bearer {refreshToken}
```

## Params

```json
x
```

## Body

```json
x
```

# Response

---

📌 Status : OK, 200

```json
eyJhbGciOiJIUzI1NiJ9.eyJuaWNrbmFtZSI6IuuwsOywveuvvCIsImVtYWlsIjoibHVkd2luZ3NAbmF2ZXIuY29tIiwicHJvdmlkZXIiOiJOQVZFUiIsImV4cCI6MTY3ODY4NTM2MH0.nv8UVLU0mPlpvpAU1WZB3Mnx3AmrjA2EfisuIQV1xE8
```

- 생성된 accessToken 이 String 으로 반환됩니다.

💥 Status : Unauthorizaed, 401

```json
x
```

💥 Status : Forbidden, 403

```json
x
```

# 참고

---

1.